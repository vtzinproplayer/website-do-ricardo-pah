import pathlib, re

root = pathlib.Path("/home/user/elite-digital")
public = root/"public"
templates = root/"templates"

def read(p): return pathlib.Path(p).read_text(encoding="utf-8")

def strip_php(text):
    return re.sub(r"<\?php.*?\?>", "", text, flags=re.DOTALL)

def build_page(page_name, title):
    header = strip_php(read(templates/"layout/header.php"))
    footer = strip_php(read(templates/"layout/footer.php"))
    page = strip_php(read(templates/f"pages/{page_name}.php"))
    html = f"""<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#E30613">
  <title>{title}</title>
  <meta name="description" content="Elite Digital by Inforlândia — Loja powered by PrestaShop. Assistente AI + Recondicionados.">
  <link rel="icon" href="https://www.elitedigital.pt/img/favicon.ico?1631183047">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="/assets/css/theme.css?v=20261012">
</head>
<body class="lang-pt country-pt currency-eur layout-full-width page-index">
{header}
<main id="main-page-content">
{page}
</main>
{footer}
<script src="/assets/js/app.js?v=20261012"></script>
</body>
</html>
"""
    # fix links for static
    html = html.replace('href="/recondicionados"', 'href="recondicionados.html"')
    html = html.replace('href="/assistente-ai"', 'href="assistente.html"')
    html = html.replace('href="/assistente"', 'href="assistente.html"')
    html = html.replace('href="/"', 'href="index.html"')
    # legacy configurador -> assistente
    html = html.replace('href="/configurador"', 'href="assistente.html"')
    html = html.replace('href="/configurador-pc"', 'href="assistente.html"')
    return html

pages = [
    ("home", "EliteDigital — Loja powered by PrestaShop", "index.html"),
    ("recondicionados", "Catálogo Recondicionados + AI | Elite Digital", "recondicionados.html"),
    ("assistente", "Assistente AI Elite — Monte o seu PC com ajuda | Elite Digital", "assistente.html"),
]

for src, title, out in pages:
    html = build_page(src, title)
    (public/out).write_text(html, encoding="utf-8")
    print(f"built {out} {len(html)} bytes")

# also keep configurador.html as alias to assistente.html for backward compat
import shutil
shutil.copy(public/"assistente.html", public/"configurador.html")
print("copied assistente.html -> configurador.html (legacy)")
print("done")
